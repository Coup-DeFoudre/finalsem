# Q2. Implement Breadth-First Search (BFS) to traverse a graph and find the shortest path.

from collections import deque

def breadth_first_search(graph, start_node, target_node):
    # Queue stores tuples of (current_node, path_taken_so_far)
    queue = deque([(start_node, [start_node])])
    visited = {start_node}
    
    while queue:
        current_node, path = queue.popleft()  # Dequeue from the front (FIFO)
        
        if current_node == target_node:
            return path  # Goal found
            
        for neighbor in graph[current_node]:
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append((neighbor, path + [neighbor]))
                
    return None

if __name__ == "__main__":
    graph_map = {
        'A': ['B', 'C'],
        'B': ['A', 'D', 'E'],
        'C': ['A', 'F'],
        'D': ['B'],
        'E': ['B', 'F'],
        'F': ['C', 'E']
    }
    
    shortest_path = breadth_first_search(graph_map, 'A', 'F')
    
    if shortest_path:
        print("Shortest path:", " -> ".join(shortest_path))
    else:
        print("Shortest path: None")

"""
OUTPUT:
Shortest path: A -> C -> F
"""
