# Q6. Implement A* search algorithm to find the shortest path in a weighted graph.

import heapq

def a_star_search(graph, heuristics, start_node, target_node):
    # Priority queue stores (f_cost, g_cost, current_node, path)
    # f_cost = g_cost + heuristic_cost
    priority_queue = [(heuristics[start_node], 0, start_node, [start_node])]
    visited_costs = {}
    
    while priority_queue:
        f_cost, current_g_cost, current_node, path = heapq.heappop(priority_queue)
        
        if current_node == target_node:
            return path, current_g_cost  # Optimal path found
            
        if current_node in visited_costs and visited_costs[current_node] <= current_g_cost:
            continue  # We already found a cheaper path to this node
            
        visited_costs[current_node] = current_g_cost
        
        for neighbor, edge_weight in graph[current_node]:
            new_g_cost = current_g_cost + edge_weight
            new_f_cost = new_g_cost + heuristics[neighbor]
            heapq.heappush(priority_queue, (new_f_cost, new_g_cost, neighbor, path + [neighbor]))
            
    return None, float('inf')

if __name__ == "__main__":
    # Graph with edge weights: (neighbor, weight)
    graph_map = {
        'A': [('B', 1), ('C', 4)],
        'B': [('A', 1), ('D', 5), ('E', 2)],
        'C': [('A', 4), ('F', 3)],
        'D': [('B', 5)],
        'E': [('B', 2), ('F', 1)],
        'F': [('C', 3), ('E', 1)]
    }
    heuristics_table = {'A': 6, 'B': 4, 'C': 2, 'D': 6, 'E': 1, 'F': 0}
    
    path, cost = a_star_search(graph_map, heuristics_table, 'A', 'F')
    if path:
        print(f"Path: {' -> '.join(path)}, Cost: {cost}")
    else:
        print("Path: None")

"""
OUTPUT:
Path: A -> B -> E -> F, Cost: 4
"""
