# Q4. Implement Hill Climbing algorithm.

import random

# Objective function, peaks at x=0
def objective_function(x):
    return -(x**2) + 10

def hill_climbing(current_x, step_size=0.1):
    while True:
        # Check neighboring states (left or right step)
        neighbors = [current_x + step_size, current_x - step_size]
        
        # Pick the best neighbor
        best_neighbor = max(neighbors, key=objective_function)
        
        # If the best neighbor does not improve the objective value, we reached a local peak
        if objective_function(best_neighbor) <= objective_function(current_x):
            break
            
        current_x = best_neighbor  # Move uphill
        
    return current_x, objective_function(current_x)

if __name__ == "__main__":
    start_x = random.uniform(-10, 10)
    solution_x, maximum_value = hill_climbing(start_x)
    print(f"Start: {start_x:.4f}, Best: x={solution_x:.4f}, f(x)={maximum_value:.4f}")

"""
OUTPUT:
Start: 1.7792, Best: x=-0.0208, f(x)=9.9996
"""
