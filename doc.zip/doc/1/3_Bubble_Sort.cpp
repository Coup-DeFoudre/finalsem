// Q3. Bubble Sort

/*
Algorithm:
BubbleSort(A, n):
1. Loop i from 0 to n-2:
2.   swapped = false
3.   Loop j from 0 to n-2-i:
4.     If A[j] > A[j+1], swap them and set swapped = true.
5.   If swapped == false, break.
*/

// Program
#include<iostream>
using namespace std;

void bubble(int a[],int n){
    for(int i=0;i<n-1;i++){
        bool swapped = false;
        for(int j=0;j<n-1-i;j++){
            if(a[j]>a[j+1]){
                swap(a[j],a[j+1]);
                swapped = true;
            }
        }
        if(!swapped) break;
    }
}

int main(){
    int a[]={5,3,8,1,2},n=5;
    cout<<"Original: "; for(int x:a) cout<<x<<" ";
    bubble(a,n);
    cout<<"\nSorted  : "; for(int x:a) cout<<x<<" ";
    cout<<endl;
}

// Output:

// Complexity:
// Best: O(n) | Avg: O(n^2) | Worst: O(n^2)
