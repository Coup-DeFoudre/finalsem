// Q3. Bubble Sort

/*
Algorithm:
BubbleSort(A, n):
1. Loop i from 0 to n-2:
2.   swapped = false
3.   Loop j from 0 to n-2-i:
4.     If A[j] > A[j+1], swap them and set swapped = true.
5.   If swapped == false, break.
*/

// Program
#include<iostream.h>
#include<conio.h>

void bubble(int a[],int n){
    int i,j,t,swapped;
    for(i=0;i<n-1;i++){
        swapped=0;
        for(j=0;j<n-1-i;j++){
            if(a[j]>a[j+1]){
                t=a[j];
                a[j]=a[j+1];
                a[j+1]=t;
                swapped=1;
            }
        }
        if(!swapped) break;
    }
}

int main(){
    int i,a[]={5,3,8,1,2},n=5;
    cout<<"Original: ";
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    bubble(a,n);
    cout<<"\nSorted  : ";
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    cout<<endl;
    getch();
    return 0;
}

// Output:

// Complexity:
// Best: O(n) | Avg: O(n^2) | Worst: O(n^2)
