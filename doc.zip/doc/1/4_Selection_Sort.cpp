// Q4. Selection Sort

/*
Algorithm:
SelectionSort(A, n):
1. Loop i from 0 to n-2:
2.   m = i
3.   Loop j from i+1 to n-1:
4.     If A[j] < A[m], m = j.
5.   Swap A[i] and A[m].
*/

// Program
#include<iostream.h>
#include<conio.h>

void selection(int a[],int n){
    int i,j,m,t;
    for(i=0;i<n-1;i++){
        m=i;
        for(j=i+1;j<n;j++)
            if(a[j]<a[m]) m=j;
        t=a[i];
        a[i]=a[m];
        a[m]=t;
    }
}

int main(){
    int i,a[]={5,3,8,1,2},n=5;
    cout<<"Original: ";
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    selection(a,n);
    cout<<"\nSorted  : ";
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    cout<<endl;
    getch();
    return 0;
}

// Output:

// Complexity:
// Best: O(n^2) | Avg: O(n^2) | Worst: O(n^2)
