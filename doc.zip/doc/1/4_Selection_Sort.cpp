// Q4. Selection Sort

/*
Algorithm:
SelectionSort(A, n):
1. Loop i from 0 to n-2:
2.   m = i
3.   Loop j from i+1 to n-1:
4.     If A[j] < A[m], m = j.
5.   Swap A[i] and A[m].
*/

// Program
#include<iostream>
using namespace std;

void selection(int a[],int n){
    for(int i=0;i<n-1;i++){
        int m=i;
        for(int j=i+1;j<n;j++)
            if(a[j]<a[m]) m=j;
        swap(a[i],a[m]);
    }
}

int main(){
    int a[]={5,3,8,1,2},n=5;
    cout<<"Original: "; for(int x:a) cout<<x<<" ";
    selection(a,n);
    cout<<"\nSorted  : "; for(int x:a) cout<<x<<" ";
    cout<<endl;
}

// Output:

// Complexity:
// Best: O(n^2) | Avg: O(n^2) | Worst: O(n^2)
