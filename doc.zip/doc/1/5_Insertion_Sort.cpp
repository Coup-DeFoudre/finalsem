// Q5. Insertion Sort

/*
Algorithm:
InsertionSort(A, n):
1. Loop i from 1 to n-1:
2.   k = A[i], j = i - 1
3.   While j >= 0 and A[j] > k:
4.     A[j+1] = A[j], j--
5.   A[j+1] = k
*/

// Program
#include<iostream>
using namespace std;

void insertion(int a[],int n){
    for(int i=1;i<n;i++){
        int k=a[i],j=i-1;
        while(j>=0&&a[j]>k){a[j+1]=a[j];j--;}
        a[j+1]=k;
    }
}

int main(){
    int a[]={5,3,8,1,2},n=5;
    cout<<"Original: "; for(int x:a) cout<<x<<" ";
    insertion(a,n);
    cout<<"\nSorted  : "; for(int x:a) cout<<x<<" ";
    cout<<endl;
}

// Output:

// Complexity:
// Best: O(n) | Avg: O(n^2) | Worst: O(n^2)
