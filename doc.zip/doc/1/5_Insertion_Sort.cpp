// Q5. Insertion Sort

/*
Algorithm:
InsertionSort(A, n):
1. Loop i from 1 to n-1:
2.   k = A[i], j = i - 1
3.   While j >= 0 and A[j] > k:
4.     A[j+1] = A[j], j--
5.   A[j+1] = k
*/

// Program
#include<iostream.h>
#include<conio.h>

void insertion(int a[],int n){
    int i,k,j;
    for(i=1;i<n;i++){
        k=a[i];
        j=i-1;
        while(j>=0&&a[j]>k){a[j+1]=a[j];j--;}
        a[j+1]=k;
    }
}

int main(){
    int i,a[]={5,3,8,1,2},n=5;
    cout<<"Original: ";
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    insertion(a,n);
    cout<<"\nSorted  : ";
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    cout<<endl;
    getch();
    return 0;
}

// Output:

// Complexity:
// Best: O(n) | Avg: O(n^2) | Worst: O(n^2)
