// Q10. Counting Sort

/*
Algorithm:
CountingSort(A, n):
1. Count frequency of each element in count array C.
2. Reconstruct A by iterating through C.
*/

// Program
#include<iostream>
using namespace std;
int main(){
    int a[]={5,3,1},n=3,c[6]={};
    cout<<"Original: "; for(int x:a) cout<<x<<" ";
    for(int i=0;i<n;i++)c[a[i]]++;
    int k=0;
    for(int i=0;i<6;i++)while(c[i]--)a[k++]=i;
    cout<<"\nSorted  : "; for(int x:a) cout<<x<<" ";
    cout<<endl;
}

// Output:

// Complexity:
// Best: O(n+k) | Avg: O(n+k) | Worst: O(n+k)
