// Q10. Counting Sort

/*
Algorithm:
CountingSort(A, n):
1. Count frequency of each element in count array C.
2. Reconstruct A by iterating through C.
*/

// Program
#include<iostream.h>
#include<conio.h>
int main(){
    int a[]={5,3,1},n=3;
    int c[6],i,k;
    for(i=0;i<6;i++) c[i]=0;
    cout<<"Original: "; 
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    for(i=0;i<n;i++) c[a[i]]++;
    k=0;
    for(i=0;i<6;i++) while(c[i]--) a[k++]=i;
    cout<<"\nSorted  : "; 
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    cout<<endl;
    getch();
}

// Output:

// Complexity:
// Best: O(n+k) | Avg: O(n+k) | Worst: O(n+k)
