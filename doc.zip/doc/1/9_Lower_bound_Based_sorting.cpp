// Q9. Lower Bound Sorting

/*
Algorithm:
LowerBoundProof:
1. Comparison-based sort represents a binary decision tree.
2. Height h tree has at most 2^h leaves.
3. n elements sorting needs >= n! leaves.
4. 2^h >= n!  =>  h >= log(n!)  =>  h = Omega(n log n).
*/

// Program
#include<iostream>
using namespace std;
void ms(int a[],int l,int r){
    if(l>=r)return;
    int m=(l+r)/2;ms(a,l,m);ms(a,m+1,r);
    int t[r-l+1],i=l,j=m+1,k=0;
    while(i<=m&&j<=r)t[k++]=a[i]<=a[j]?a[i++]:a[j++];
    while(i<=m)t[k++]=a[i++];
    while(j<=r)t[k++]=a[j++];
    for(i=0;i<k;i++)a[l+i]=t[i];
}
int main(){
    int a[]={5,3,1},n=3;
    cout<<"Original: "; for(int x:a) cout<<x<<" ";
    ms(a,0,n-1);
    cout<<"\nSorted  : "; for(int x:a) cout<<x<<" ";
    cout<<endl;
}

// Output:

// Complexity:
// Best: Omega(n log n) | Avg: Omega(n log n) | Worst: Omega(n log n)
