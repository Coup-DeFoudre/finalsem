// Q9. Lower Bound Sorting

/*
Algorithm:
LowerBoundProof:
1. Comparison-based sort represents a binary decision tree.
2. Height h tree has at most 2^h leaves.
3. n elements sorting needs >= n! leaves.
4. 2^h >= n!  =>  h >= log(n!)  =>  h = Omega(n log n).
*/

// Program
#include<iostream.h>
#include<conio.h>
void ms(int a[],int l,int r){
    int m,t[100],i,j,k;
    if(l>=r)return;
    m=(l+r)/2; ms(a,l,m); ms(a,m+1,r);
    i=l; j=m+1; k=0;
    while(i<=m&&j<=r)t[k++]=a[i]<=a[j]?a[i++]:a[j++];
    while(i<=m)t[k++]=a[i++];
    while(j<=r)t[k++]=a[j++];
    for(i=0;i<k;i++)a[l+i]=t[i];
}
int main(){
    int a[]={5,3,1},n=3,i;
    cout<<"Original: "; 
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    ms(a,0,n-1);
    cout<<"\nSorted  : "; 
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    cout<<endl;
    getch();
}

// Output:

// Complexity:
// Best: Omega(n log n) | Avg: Omega(n log n) | Worst: Omega(n log n)
