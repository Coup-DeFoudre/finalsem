// Q1. Linear Search

/*
Algorithm:
LinearSearch(A, n, k):
1. Loop i from 0 to n-1:
2.   If A[i] == k, return i.
3. Return -1.
*/

// Program
#include<iostream>
using namespace std;

int search(int a[],int n,int k){
    for(int i=0;i<n;i++)
        if(a[i]==k) return i;
    return -1;
}

int main(){
    int a[]={4,2,7,1,9},n=5,k=7;
    cout<<"Array: "; for(int x:a) cout<<x<<" ";
    cout<<"\nSearch Key: "<<k;
    cout<<"\nResult: Found at index "<<search(a,n,k)<<endl;
}

// Output:

// Complexity:
// Best: O(1) | Avg: O(n) | Worst: O(n)
