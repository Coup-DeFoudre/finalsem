// Q2. Binary Search (Divide and Conquer)

/*
Algorithm:
BinarySearch(A, l, r, k):
1. If l > r, return -1.
2. m = (l + r) / 2.
3. If A[m] == k, return m.
4. If k < A[m], return BinarySearch(A, l, m-1, k).
5. Else, return BinarySearch(A, m+1, r, k).
*/

// Program
#include<iostream>
using namespace std;

int bs(int a[],int l,int r,int k){
    if(l>r) return -1;
    int m=(l+r)/2;
    if(a[m]==k) return m;
    if(k<a[m]) return bs(a,l,m-1,k);
    return bs(a,m+1,r,k);
}

int main(){
    int a[]={1,3,5,7,9,11},n=6,k=7;
    cout<<"Sorted Array: "; for(int x:a) cout<<x<<" ";
    cout<<"\nSearch Key: "<<k;
    cout<<"\nResult: Found at index "<<bs(a,0,n-1,k)<<endl;
}

// Output:

// Complexity:
// Best: O(1) | Avg: O(log n) | Worst: O(log n)
