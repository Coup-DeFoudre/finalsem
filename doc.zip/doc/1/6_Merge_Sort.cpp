// Q6. Merge Sort

/*
Algorithm:
MergeSort(A, l, r):
1. If l < r:
2.   m = (l + r) / 2
3.   MergeSort(A, l, m)
4.   MergeSort(A, m+1, r)
5.   Merge(A, l, m, r)
*/

// Program
#include<iostream.h>
#include<conio.h>
void mg(int a[],int l,int m,int r){
    int i,j,k,t[100];
    i=l; j=m+1; k=0;
    while(i<=m&&j<=r) t[k++]=(a[i]<=a[j])?a[i++]:a[j++];
    while(i<=m) t[k++]=a[i++];
    while(j<=r) t[k++]=a[j++];
    for(i=0;i<k;i++) a[l+i]=t[i];
}
void ms(int a[],int l,int r){
    int m;
    if(l<r){m=(l+r)/2;ms(a,l,m);ms(a,m+1,r);mg(a,l,m,r);}
}
int main(){
    int a[]={5,3,1},n=3,i;
    cout<<"Original: "; 
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    ms(a,0,n-1);
    cout<<"\nSorted  : "; 
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    cout<<endl;
    getch();
}

// Output:

// Complexity:
// Best: O(n log n) | Avg: O(n log n) | Worst: O(n log n)
