// Q8. Heap Sort

/*
Algorithm:
HeapSort(A, n):
1. Loop i from n/2-1 down to 0: heapify(A, n, i)
2. Loop i from n-1 down to 1:
3.   swap(A[0], A[i])
4.   heapify(A, i, 0)
*/

// Program
#include<iostream.h>
#include<conio.h>
void hf(int a[],int n,int i){
    int l,r,m,t;
    l=2*i+1; r=2*i+2; m=i;
    if(l<n&&a[l]>a[m])m=l;
    if(r<n&&a[r]>a[m])m=r;
    if(m!=i){
        t=a[i];a[i]=a[m];a[m]=t;
        hf(a,n,m);
    }
}
int main(){
    int a[]={5,3,1},n=3,i,t;
    cout<<"Original: "; 
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    for(i=n/2-1;i>=0;i--) hf(a,n,i);
    for(i=n-1;i>0;i--){
        t=a[0];a[0]=a[i];a[i]=t;
        hf(a,i,0);
    }
    cout<<"\nSorted  : "; 
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    cout<<endl;
    getch();
}

// Output:

// Complexity:
// Best: O(n log n) | Avg: O(n log n) | Worst: O(n log n)
