// Q8. Heap Sort

/*
Algorithm:
HeapSort(A, n):
1. Loop i from n/2-1 down to 0: heapify(A, n, i)
2. Loop i from n-1 down to 1:
3.   swap(A[0], A[i])
4.   heapify(A, i, 0)
*/

// Program
#include<iostream>
using namespace std;
void hf(int a[],int n,int i){
    int l=2*i+1,r=2*i+2,m=i;
    if(l<n&&a[l]>a[m])m=l;
    if(r<n&&a[r]>a[m])m=r;
    if(m!=i){swap(a[i],a[m]);hf(a,n,m);}
}
int main(){
    int a[]={5,3,1},n=3;
    cout<<"Original: "; for(int x:a) cout<<x<<" ";
    for(int i=n/2-1;i>=0;i--)hf(a,n,i);
    for(int i=n-1;i>0;i--){swap(a[0],a[i]);hf(a,i,0);}
    cout<<"\nSorted  : "; for(int x:a) cout<<x<<" ";
    cout<<endl;
}

// Output:

// Complexity:
// Best: O(n log n) | Avg: O(n log n) | Worst: O(n log n)
