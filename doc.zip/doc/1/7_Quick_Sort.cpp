// Q7. Quick Sort

/*
Algorithm:
QuickSort(A, l, r):
1. If l >= r, return.
2. p = A[r], i = l
3. Loop j from l to r-1:
4.   If A[j] <= p, swap A[i] and A[j], i++
5. Swap A[i] and A[r]
6. QuickSort(A, l, i-1)
7. QuickSort(A, i+1, r)
*/

// Program
#include<iostream.h>
#include<conio.h>
void qs(int a[],int l,int r){
    int p,i,j,t;
    if(l>=r)return;
    p=a[r]; i=l;
    for(j=l;j<r;j++){
        if(a[j]<=p){
            t=a[i];a[i]=a[j];a[j]=t;
            i++;
        }
    }
    t=a[i];a[i]=a[r];a[r]=t;
    qs(a,l,i-1);qs(a,i+1,r);
}
int main(){
    int a[]={5,3,1},n=3,i;
    cout<<"Original: "; 
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    qs(a,0,n-1);
    cout<<"\nSorted  : "; 
    for(i=0;i<n;i++) cout<<a[i]<<" ";
    cout<<endl;
    getch();
}

// Output:

// Complexity:
// Best: O(n log n) | Avg: O(n log n) | Worst: O(n^2)
