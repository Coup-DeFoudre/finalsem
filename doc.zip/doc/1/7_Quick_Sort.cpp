// Q7. Quick Sort

/*
Algorithm:
QuickSort(A, l, r):
1. If l >= r, return.
2. p = A[r], i = l
3. Loop j from l to r-1:
4.   If A[j] <= p, swap A[i] and A[j], i++
5. Swap A[i] and A[r]
6. QuickSort(A, l, i-1)
7. QuickSort(A, i+1, r)
*/

// Program
#include<iostream>
using namespace std;
void qs(int a[],int l,int r){
    if(l>=r)return;
    int p=a[r],i=l;
    for(int j=l;j<r;j++)if(a[j]<=p)swap(a[i++],a[j]);
    swap(a[i],a[r]);
    qs(a,l,i-1);qs(a,i+1,r);
}
int main(){
    int a[]={5,3,1},n=3;
    cout<<"Original: "; for(int x:a) cout<<x<<" ";
    qs(a,0,n-1);
    cout<<"\nSorted  : "; for(int x:a) cout<<x<<" ";
    cout<<endl;
}

// Output:

// Complexity:
// Best: O(n log n) | Avg: O(n log n) | Worst: O(n^2)
