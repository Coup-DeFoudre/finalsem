# Q5. Implement Greedy Best-First Search using heuristic values.

import heapq

def greedy_best_first_search(graph, heuristics, start_node, target_node):
    # Priority queue stores tuples of (heuristic_value, current_node, path)
    priority_queue = [(heuristics[start_node], start_node, [start_node])]
    visited = set()
    
    while priority_queue:
        # Pop the node with the smallest heuristic value
        _, current_node, path = heapq.heappop(priority_queue)
        
        if current_node == target_node:
            return path  # Goal reached
            
        if current_node in visited:
            continue
            
        visited.add(current_node)
        
        for neighbor in graph[current_node]:
            if neighbor not in visited:
                heapq.heappush(priority_queue, (heuristics[neighbor], neighbor, path + [neighbor]))
                
    return None

if __name__ == "__main__":
    graph_map = {
        'A': ['B', 'C'],
        'B': ['A', 'D', 'E'],
        'C': ['A', 'F'],
        'D': ['B'],
        'E': ['B', 'F'],
        'F': ['C', 'E']
    }
    # Heuristic estimates distance to the goal 'F'
    heuristics_table = {'A': 5, 'B': 4, 'C': 2, 'D': 6, 'E': 1, 'F': 0}
    
    path = greedy_best_first_search(graph_map, heuristics_table, 'A', 'F')
    if path:
        print("Path:", " -> ".join(path))
    else:
        print("Path: None")

"""
OUTPUT:
Path: A -> C -> F
"""
