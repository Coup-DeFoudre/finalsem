# Q7. Implement AO* algorithm to solve an AND-OR graph problem.

import math

def ao_star(graph, heuristics, start_node):
    costs = dict(heuristics)
    solution = {}
    solved_nodes = set()

    def update_node(node):
        # Base case: if node has no children, it is a terminal node
        if not graph.get(node):
            solved_nodes.add(node)
            return

        best_cost = math.inf
        best_group = None

        # Explore all AND groups connected by OR choices
        for and_group in graph[node]:
            # Calculate total cost of this AND group
            group_cost = sum(costs[child] + edge_weight for child, edge_weight in and_group)
            if group_cost < best_cost:
                best_cost = group_cost
                best_group = and_group

        costs[node] = best_cost
        solution[node] = best_group

        # Check if this node can be marked as solved
        if all(child in solved_nodes for child, _ in best_group):
            solved_nodes.add(node)

        # Recursively update unsolved children
        for child, _ in best_group:
            if child not in solved_nodes:
                update_node(child)

    update_node(start_node)
    return costs[start_node], solution

def print_solution_tree(solution, node, depth=0):
    print("  " * depth + node)
    if node in solution:
        for child, _ in solution[node]:
            print_solution_tree(solution, child, depth + 1)

if __name__ == "__main__":
    # Node 'A' has an OR choice:
    # 1. Solve 'B' AND 'C' together (cost 1 each)
    # 2. Solve 'D' alone (cost 5)
    graph_map = {
        'A': [
            [('B', 1), ('C', 1)],  # AND group 1
            [('D', 5)]             # AND group 2
        ],
        'B': [], 'C': [], 'D': []
    }
    
    heuristics_table = {key: 0 for key in graph_map}
    
    total_cost, solution_tree = ao_star(graph_map, heuristics_table, 'A')
    
    print(f"Cost: {total_cost}")
    print("Tree:")
    print_solution_tree(solution_tree, 'A')

"""
OUTPUT:
Cost: 2
Tree:
A
  B
  C
"""
