# Q3. Implement Depth-First Search (DFS) using recursion to traverse a graph.

def depth_first_search(graph, current_node, visited=None):
    if visited is None:
        visited = set()  # Initialize visited set on the first call
        
    visited.add(current_node)  # Mark the current node as visited
    print(current_node, end=" ")  # Process the node
    
    for neighbor in graph[current_node]:
        if neighbor not in visited:
            depth_first_search(graph, neighbor, visited)

if __name__ == "__main__":
    graph_map = {
        'A': ['B', 'C'],
        'B': ['A', 'D', 'E'],
        'C': ['A', 'F'],
        'D': ['B'],
        'E': ['B', 'F'],
        'F': ['C', 'E']
    }
    
    print("DFS traversal:")
    depth_first_search(graph_map, 'A')
    print() # Print a newline at the end

"""
OUTPUT:
DFS traversal:
A B D E F C
"""
