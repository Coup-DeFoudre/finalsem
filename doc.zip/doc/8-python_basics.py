# Q8. Python Basic Programming including Python Data Structures such as List, Tuple, Strings, Dictionary, Lambda Functions, Python Classes and Objects.

if __name__ == "__main__":
    # 1. List (Mutable, ordered collection)
    numbers_list = [1, 2, 3]
    numbers_list.append(4)
    print(f"List: {numbers_list}")

    # 2. Tuple (Immutable, ordered collection)
    coordinates_tuple = (10, 20, 30)
    print(f"Tuple: {coordinates_tuple}")

    # 3. String (Immutable sequence of characters)
    greeting_string = "Hello"
    print(f"String: {greeting_string.upper()} {greeting_string[::-1]}")  # Uppercase and reversed

    # 4. Dictionary (Key-value pairs)
    point_dict = {"x": 1, "y": 2}
    point_dict["z"] = 3
    print(f"Dictionary: {point_dict}")

    # 5. Lambda Function (Anonymous function)
    square_lambda = lambda x: x ** 2
    print(f"Lambda Function: {square_lambda(5)}")

    # 6. Class & Object
    class Student:
        def __init__(self, name, marks):
            self.name = name
            self.marks = marks
            
        def check_result(self):
            return "Pass" if self.marks >= 40 else "Fail"

    student_object = Student("Bob", 75)
    print(f"Class & Object: Student: {student_object.name}, Marks: {student_object.marks}, Result: {student_object.check_result()}")

"""
OUTPUT:
List: [1, 2, 3, 4]
Tuple: (10, 20, 30)
String: HELLO olleH
Dictionary: {'x': 1, 'y': 2, 'z': 3}
Lambda Function: 25
Class & Object: Student: Bob, Marks: 75, Result: Pass
"""
