// 8) Kruskal Algorithm (Greedy)

Algorithm

Sort all edges by weight
Initialize disjoint set

for each edge (u,v):
    if find(u) != find(v):
        add edge to MST
        union(u,v)

Complexity
* Best = O(E log E)
* Average = O(E log E)
* Worst = O(E log E)
* Space = O(V)
