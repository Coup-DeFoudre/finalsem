// 5) BFS (Breadth First Search)

Algorithm

Input: Graph G(V,E), start node s

Create queue Q
mark s visited and enqueue

while Q not empty:
    u = dequeue
    for each neighbor v of u:
        if v not visited:
            mark visited
            enqueue v

Complexity
* Best = O(V)
* Average = O(V+E)
* Worst = O(V+E)
* Space = O(V)
