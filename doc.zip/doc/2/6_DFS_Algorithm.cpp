// 6) DFS (Depth First Search)

Algorithm

DFS(u):
    mark u visited
    for each neighbor v:
        if v not visited:
            DFS(v)

Complexity
* Best = O(V)
* Average = O(V+E)
* Worst = O(V+E)
* Space = O(V)
