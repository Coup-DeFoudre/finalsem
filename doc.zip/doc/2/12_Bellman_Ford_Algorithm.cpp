// 12) Bellman-Ford Algorithm

Algorithm

Initialize dist[source]=0

for i = 1 to V-1:
    for each edge (u,v):
        if dist[u] + weight < dist[v]:
            update dist[v]

Check negative cycle

Complexity
* Best = O(E) (early stop)
* Average = O(VE)
* Worst = O(VE)
* Space = O(V)
