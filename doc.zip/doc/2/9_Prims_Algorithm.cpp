// 9) Prim's Algorithm (Greedy)

Algorithm

Initialize key[] = infinity, key[start] = 0
Use priority queue

while queue not empty:
    u = extract min
    for each neighbor v:
        if weight(u,v) < key[v]:
            update key[v]

Complexity
* Best = O(E log V)
* Average = O(E log V)
* Worst = O(E log V)
* Space = O(V)
