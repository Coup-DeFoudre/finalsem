// 11) Dijkstra Algorithm

Algorithm

Initialize dist[source]=0, others=infinity
Use priority queue

while queue not empty:
    u = extract min
    for each neighbor v:
        if dist[u] + weight(u,v) < dist[v]:
            update dist[v]

Complexity
* Best = O(E log V)
* Average = O(E log V)
* Worst = O(E log V)
* Space = O(V)

With Fibonacci Heap -> O(E + V log V)
