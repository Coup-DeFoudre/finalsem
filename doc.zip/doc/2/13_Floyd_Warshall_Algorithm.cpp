// 13) Floyd-Warshall Algorithm

Algorithm

Initialize dist[i][j]

for k = 1 to n:
    for i = 1 to n:
        for j = 1 to n:
            dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j])

Complexity
* Best = O(n^3)
* Average = O(n^3)
* Worst = O(n^3)
* Space = O(n^2)
