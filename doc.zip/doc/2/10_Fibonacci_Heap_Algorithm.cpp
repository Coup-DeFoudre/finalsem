// Fibonacci Heap Algorithm

1) Insert(H, x)

    create node x
    x.degree = 0
    x.parent = NIL
    x.child = NIL
    
    add x to root list of H
    
    if H.min == NIL or x.key < H.min.key:
        H.min = x

2) Extract-Min(H)

    z = H.min
    
    if z != NIL:
        for each child x of z:
            add x to root list
            x.parent = NIL
            
        remove z from root list
        
        if z == z.right:
            H.min = NIL
        else:
            H.min = z.right
            CONSOLIDATE(H)
            
    return z

3) Decrease-Key(H, x, k)

    if k > x.key:
        return error
        
    x.key = k
    y = x.parent
    
    if y != NIL and x.key < y.key:
        cut x from y
        add x to root list
        CASCADING-CUT(H, y)
        
    if x.key < H.min.key:
        H.min = x

Time Complexity
* Insert -> O(1)
* Decrease-Key -> O(1)
* Extract-Min -> O(log n)

Space Complexity
* O(n)
