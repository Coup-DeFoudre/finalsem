// 1) 0/1 Knapsack (Dynamic Programming)

Algorithm

Input: weight[1..n], value[1..n], capacity W

Create dp[n+1][W+1]

for i = 0 to n:
    for w = 0 to W:
        if i == 0 or w == 0:
            dp[i][w] = 0
        else if weight[i] <= w:
            dp[i][w] = max(value[i] + dp[i-1][w-weight[i]], dp[i-1][w])
        else:
            dp[i][w] = dp[i-1][w]

return dp[n][W]

Complexity
* Best = O(nW)
* Average = O(nW)
* Worst = O(nW)
* Space = O(nW) (or O(W) optimized)
