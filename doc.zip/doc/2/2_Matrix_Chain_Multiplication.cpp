// 2) Matrix Chain Multiplication (DP)

Algorithm

Input: p[0..n]

for i = 1 to n:
    dp[i][i] = 0

for length = 2 to n:
    for i = 1 to n-length+1:
        j = i + length - 1
        dp[i][j] = infinity
        for k = i to j-1:
            cost = dp[i][k] + dp[k+1][j] + p[i-1]*p[k]*p[j]
            dp[i][j] = min(dp[i][j], cost)

return dp[1][n]

Complexity
* Best = O(n^3)
* Average = O(n^3)
* Worst = O(n^3)
* Space = O(n^2)
