# Q1. Develop a rule-based expert system inspired by Nyaya logic using IF–THEN production rules.

# Rules: (condition, conclusion) — IF symptoms match THEN infer diagnosis
rules = [
    ({"fever", "cough"}, "Flu"),
    ({"fever", "rash"}, "Measles"),
    ({"cough", "breathing_difficulty"}, "Asthma"),
    ({"headache", "stiff_neck"}, "Meningitis"),
]

# Get symptoms from user, build a set
user_input = input("Enter symptoms (comma-separated): ")
symptoms = set(user_input.replace(" ", "").split(","))

# Fire matching rules: if rule's conditions are a subset of user symptoms
diagnoses = []
for condition, conclusion in rules:
    if condition <= symptoms:  # Subset check
        diagnoses.append(conclusion)

if diagnoses:
    print("Diagnosis:", ", ".join(diagnoses))
else:
    print("Diagnosis: Unknown")

"""
OUTPUT:
Enter symptoms (comma-sep): fever,cough
Diagnosis: Flu
"""
